package DAO;

import java.sql.Connection;
import java.sql.ResultSet;
import Objeto.Cliente;
import conexao.Mysql;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class usuarioDAO {

    Connection conn;
     

    public ResultSet autenticacao(Cliente objusuario) {

        conn = new Mysql().conectaBanco();

        try {

            String sql = "select * from usuario where email = ? and senha = ?";
            
            PreparedStatement pstm = conn.prepareStatement(sql);
            
            pstm.setString(1, objusuario.getEmail());
            pstm.setString(2, objusuario.getSenha());
            
            ResultSet rs = pstm.executeQuery();
            return rs;

        } catch (SQLException erro) {

            JOptionPane.showMessageDialog(null, "Usuario: " + erro);
            return null;

        }

    }
    
    public ResultSet preencherCampos(){
        conn = new Mysql().conectaBanco();
        
        try {

            String sql = "select * from usuario order by nome";
            
            PreparedStatement pstm = conn.prepareStatement(sql);

            ResultSet rs = pstm.executeQuery();
            return rs;

        } catch (SQLException erro) {

            JOptionPane.showMessageDialog(null, "Usuario: " + erro);
            return null;

        }
    }


}
