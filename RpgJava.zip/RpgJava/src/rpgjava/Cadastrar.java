package rpgjava;
import javax.swing.*;
import conexao.Mysql;
import Objeto.Cliente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


public class Cadastrar extends javax.swing.JFrame {

    Mysql conectar = new Mysql();
    Cliente novoCliente = new Cliente();

    public String senha;
    public String confirmasenha;
    
    boolean erro = false;

    
    public Cadastrar() {
        
        initComponents();
    }

    private void limpform(){
    nometxt.setText("");
    senhatxt.setText("");
    confirmsenhatxt.setText("");
    emailtxt.setText("");
    }
    
    Connection conn;

   private ResultSet CadastrarCliente(Cliente novoCliente){

        this.conectar.conectaBanco();
        
        conn = new Mysql().conectaBanco();

        char[] pass1 = senhatxt.getPassword();
        char[] pass2 = confirmsenhatxt.getPassword();
        this.senha = new String(pass1);
        this.confirmasenha = new String(pass2);
        
        if(nometxt.getText().isEmpty() || emailtxt.getText().isEmpty() || senha.isEmpty() || confirmasenha.isEmpty()){
         JOptionPane.showMessageDialog(null, "Preencha todos os campos"); 
        }
        else{
        if(senha.equals(confirmasenha)){

        novoCliente.setNome(nometxt.getText());
        novoCliente.setSenha(senha);
        novoCliente.setEmail(emailtxt.getText());

        try{
            
          
            
            String sql = "select * from usuario where email = ?";
            PreparedStatement pstm = conn.prepareStatement(sql);
            
            pstm.setString(1, novoCliente.getEmail());
            
            ResultSet rs = pstm.executeQuery();
 
            if (rs.next()){
                
                JOptionPane.showMessageDialog(null, "Email já cadastrado");
                
            }else{
                
                int tier = novoCliente.getTier();
                
                this.conectar.insertSQL("INSERT INTO usuario ("
                    + "nome,"
                    + "tier,"
                    + "senha,"
                    + "email"
                + ") VALUES ("
                    + "'" + novoCliente.getNome() + "',"
                    + "'" + tier + "',"
                    + "'" + novoCliente.getSenha() + "',"
                    + "'" + novoCliente.getEmail() + "'"
                + ");");
                
                JOptionPane.showMessageDialog(null, "Cliente cadastrado!");
                        
            }

            
        }catch(Exception e){

            System.out.println("Erro ao cadastrar o cliente " +e.getMessage());

        }finally{

            this.conectar.fechaBanco();
        }
   
            
        }
        else{
         JOptionPane.showMessageDialog(null, "Senhas não coencidem");  
        }
        }
        return null;

    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jFrame1 = new javax.swing.JFrame();
        jFrame2 = new javax.swing.JFrame();
        jPanel1 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        emailtxt = new javax.swing.JTextField();
        confirmsenhatxt = new javax.swing.JPasswordField();
        senhatxt = new javax.swing.JPasswordField();
        jLabel4 = new javax.swing.JLabel();
        btnlimpar = new javax.swing.JButton();
        btnenviar = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        nometxt = new javax.swing.JTextField();
        background = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();

        javax.swing.GroupLayout jFrame1Layout = new javax.swing.GroupLayout(jFrame1.getContentPane());
        jFrame1.getContentPane().setLayout(jFrame1Layout);
        jFrame1Layout.setHorizontalGroup(
            jFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jFrame1Layout.setVerticalGroup(
            jFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jFrame2Layout = new javax.swing.GroupLayout(jFrame2.getContentPane());
        jFrame2.getContentPane().setLayout(jFrame2Layout);
        jFrame2Layout.setHorizontalGroup(
            jFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jFrame2Layout.setVerticalGroup(
            jFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(204, 204, 255));

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel6.setFont(new java.awt.Font("Dialog", 1, 36)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Criar Conta");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 210, 210, 50));

        emailtxt.setBackground(new java.awt.Color(51, 51, 51));
        emailtxt.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        emailtxt.setForeground(new java.awt.Color(204, 204, 204));
        jPanel1.add(emailtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 470, 260, 30));

        confirmsenhatxt.setBackground(new java.awt.Color(51, 51, 51));
        confirmsenhatxt.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        confirmsenhatxt.setForeground(new java.awt.Color(153, 153, 153));
        confirmsenhatxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                confirmsenhatxtActionPerformed(evt);
            }
        });
        jPanel1.add(confirmsenhatxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 410, 260, 30));

        senhatxt.setBackground(new java.awt.Color(51, 51, 51));
        senhatxt.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        senhatxt.setForeground(new java.awt.Color(153, 153, 153));
        senhatxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                senhatxtActionPerformed(evt);
            }
        });
        jPanel1.add(senhatxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 350, 260, 30));

        jLabel4.setBackground(new java.awt.Color(255, 255, 255));
        jLabel4.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(204, 204, 204));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel4.setText("Email");
        jLabel4.setToolTipText("");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 440, 170, 30));

        btnlimpar.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        btnlimpar.setText("limpar");
        btnlimpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnlimparActionPerformed(evt);
            }
        });
        jPanel1.add(btnlimpar, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 530, 90, 30));

        btnenviar.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        btnenviar.setText("enviar");
        btnenviar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnenviarActionPerformed(evt);
            }
        });
        jPanel1.add(btnenviar, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 530, 90, 30));

        jLabel5.setBackground(new java.awt.Color(255, 255, 255));
        jLabel5.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(204, 204, 204));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel5.setText("Confirmar senha");
        jLabel5.setToolTipText("");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 380, 170, 30));

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(204, 204, 204));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel2.setText("Senha");
        jLabel2.setToolTipText("");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 320, 170, 30));

        jLabel3.setBackground(new java.awt.Color(255, 255, 255));
        jLabel3.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(204, 204, 204));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel3.setText("Nome de usuario");
        jLabel3.setToolTipText("");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 260, 170, 30));

        nometxt.setBackground(new java.awt.Color(51, 51, 51));
        nometxt.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        nometxt.setForeground(new java.awt.Color(204, 204, 204));
        jPanel1.add(nometxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 290, 260, 30));

        background.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/LOGOTIPOOOOOOOO.png"))); // NOI18N
        jPanel1.add(background, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1146, 651));

        jMenu1.setText("File");
        jMenuBar1.add(jMenu1);

        jMenu2.setText("Edit");
        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 643, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void senhatxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_senhatxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_senhatxtActionPerformed

    private void btnlimparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnlimparActionPerformed
        limpform();
    }//GEN-LAST:event_btnlimparActionPerformed

    private void confirmsenhatxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_confirmsenhatxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_confirmsenhatxtActionPerformed

    private void btnenviarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnenviarActionPerformed

    CadastrarCliente(novoCliente); 
    LoginRpg obj = new LoginRpg();
    obj.setVisible(true);
    dispose();
        
    }//GEN-LAST:event_btnenviarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Cadastrar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Cadastrar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Cadastrar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Cadastrar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Cadastrar().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel background;
    private javax.swing.JButton btnenviar;
    private javax.swing.JButton btnlimpar;
    private javax.swing.JPasswordField confirmsenhatxt;
    private javax.swing.JTextField emailtxt;
    private javax.swing.JFrame jFrame1;
    private javax.swing.JFrame jFrame2;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField nometxt;
    private javax.swing.JPasswordField senhatxt;
    // End of variables declaration//GEN-END:variables
}
