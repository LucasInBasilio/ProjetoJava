
package Objeto;

public class JavaProdutos {
    
    private int id;
    private String produto;
    private float valor;
    private int estoque;
    private int raridade;

    public String getProduto() {
        return produto;
    }

    public void setProduto(String produto) {
        this.produto = produto;
    }

    public float getValor() {
        return valor;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }

    public int getEstoque() {
        return estoque;
    }

    public int getRaridade() {
        return raridade;
    }

    public void setEstoque(int estoque) {
        this.estoque = estoque;
    }

    public void setRaridade(int raridade) {
        this.raridade = raridade;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    
    
   
}
