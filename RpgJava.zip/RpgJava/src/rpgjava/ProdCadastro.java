package rpgjava;

import Objeto.JavaProdutos;
import conexao.Mysql;
import java.sql.Connection;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

public class ProdCadastro extends javax.swing.JFrame {
    
    Mysql conectar = new Mysql();
    JavaProdutos novoProduto = new JavaProdutos();


    public ProdCadastro() {
        initComponents();
    }
    
    Connection conn;
    
    private void limpform(){
        
        txttipo.setText("");
        txtvalor.setText("");
        txtestoque.setText("");
        txtraridade.setText("");
    }
    
    private ResultSet CadastrarProduto(JavaProdutos novoProduto){

        this.conectar.conectaBanco();
        
        conn = new Mysql().conectaBanco();
        
        if(txttipo.getText().isEmpty() || txtvalor.getText().isEmpty() || txtestoque.getText().isEmpty() || txtraridade.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Preencha todos os campos"); 
        }
        else{
            novoProduto.setProduto(txttipo.getText());
            novoProduto.setValor(Float.parseFloat(txtvalor.getText()));
            novoProduto.setEstoque(Integer.parseInt(txtestoque.getText()));
            novoProduto.setRaridade(Integer.parseInt(txtraridade.getText()));

            try{

                    this.conectar.insertSQL("INSERT INTO produto ("
                        + "tipo,"
                        + "preco,"
                        + "qtdestoque,"
                        + "raridade"
                    + ") VALUES ("
                        + "'" + novoProduto.getProduto() + "',"
                        + "'" + novoProduto.getValor() + "',"
                        + "'" + novoProduto.getEstoque() + "',"
                        + "'" + novoProduto.getRaridade() + "'"
                    + ");");

                    JOptionPane.showMessageDialog(null, "Produto Cadastrado!");


            }catch(Exception e){

                System.out.println("Erro ao cadastrar o produto " +e.getMessage());

            }finally{

                this.conectar.fechaBanco();
            }

        }
        return null;

    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        txttipo = new javax.swing.JTextField();
        txtvalor = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtraridade = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtestoque = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel1.add(txttipo, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 70, 220, -1));

        txtvalor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtvalorActionPerformed(evt);
            }
        });
        jPanel1.add(txtvalor, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 130, 130, -1));

        jLabel6.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        jLabel6.setText("Cadastrar");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 120, 40));

        jButton2.setText("INCLUIR");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 320, 110, 30));

        jButton3.setText("CANCELAR");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 320, 110, 30));

        jLabel1.setText("VALOR");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 130, -1, -1));

        jLabel2.setText("PRODUTOS");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 70, -1, -1));

        jLabel3.setText("Raridade");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 230, -1, -1));

        txtraridade.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtraridadeActionPerformed(evt);
            }
        });
        jPanel1.add(txtraridade, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 230, 60, -1));

        jLabel4.setText("Estoque");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 180, -1, -1));

        txtestoque.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtestoqueActionPerformed(evt);
            }
        });
        jPanel1.add(txtestoque, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 180, 60, -1));

        jLabel5.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel5.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 430, 360));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 452, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 393, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtvalorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtvalorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtvalorActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        limpform();
        
        ViewVendas obj = new ViewVendas();
                obj.setVisible(true);
                dispose();
        
    }//GEN-LAST:event_jButton3ActionPerformed

    private void txtestoqueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtestoqueActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtestoqueActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        CadastrarProduto(novoProduto);
        ViewVendas obj = new ViewVendas();
        obj.setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void txtraridadeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtraridadeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtraridadeActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ProdCadastro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ProdCadastro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ProdCadastro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ProdCadastro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ProdCadastro().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField txtestoque;
    private javax.swing.JTextField txtraridade;
    private javax.swing.JTextField txttipo;
    private javax.swing.JTextField txtvalor;
    // End of variables declaration//GEN-END:variables
}
