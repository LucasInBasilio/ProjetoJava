
package rpgjava;

public class RpgJava {

    public static void main(String[] args) {

            //String nome,email,senha,confirmasenha;
        
            Cadastrar form = new Cadastrar();
            
             //Cliente  cliente1 = new Cliente(form.nome,form.email,form.senha,form.confirmasenha);
           
             //cliente1.imprimiCliente();
    }
    
}
