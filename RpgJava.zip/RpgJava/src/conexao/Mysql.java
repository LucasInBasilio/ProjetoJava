package conexao;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

//import java.swing.JOptionPane;

public class Mysql {
    
    private Connection conn = null;
    private Statement stmt;
    private ResultSet resultSet;
    
    private String servidor = "localhost";
    private String nomeBanco = "lojarpg";
    private String usuario = "root";
    private String senha = "";

    public Mysql() {
    }

    public Mysql(String servidor, String nomeBanco, String usuario, String senha) {
        this.servidor = servidor;
        this.nomeBanco = nomeBanco;
        this.usuario = usuario;
        this.senha = senha;
    }

    public Connection getConn() {
        return conn;
    }

    public void setConn(Connection conn) {
        this.conn = conn;
    }

    public Statement getStmt() {
        return stmt;
    }

    public void setStmt(Statement stmt) {
        this.stmt = stmt;
    }

    public ResultSet getResultSet() {
        return resultSet;
    }

    public void setResultSet(ResultSet resultSet) {
        this.resultSet = resultSet;
    }

    public Connection conectaBanco(){
        
        try {
       conn = DriverManager.getConnection("jdbc:mysql://" + servidor + "/" + nomeBanco, usuario, senha);
            
            if(conn != null){
                
                System.out.println("Conexão efetuada com sucesso! " + "ID: " + conn);
    
            }

            
        }catch (Exception e){
            
            System.out.println("Conexão não realizada - ERRO: " + e.getMessage());
            
        }
        return conn;
    }
    
    public boolean fechaBanco(){
        
        try{
            
            conn.close();
            return true;
            
        }catch(Exception e){
            
            System.out.println("Erro ao fechar a conexão: " + e.getMessage());
            return false;
            
        }
    }
    
    public int insertSQL(String SQL){
        
        int status = 0;
        
        try{
            
            this.setStmt(getConn().createStatement());
            
            this.getStmt().executeUpdate(SQL);
            
            return status;
            
        }catch(SQLException ex){
            
            ex.printStackTrace();
            return status;
        }
        
    }
    
    public void executarSQL(String sql) {
        try {
            this.stmt = conn.createStatement(
                    ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
            this.resultSet = this.stmt.executeQuery(sql);

//            while (this.getResultSet().next()) {
//                System.out.println(this.getResultSet().getInt(1));
//            }
        } catch (SQLException sqlex) {
            sqlex.printStackTrace();
        }
    }
    
    public boolean updateSQL(String pSQL){
        try {            
            //createStatement de con para criar o Statement
            this.setStmt(getConn().createStatement());

            // Definido o Statement, executamos a query no banco de dados
            getStmt().executeUpdate(pSQL);
            
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
        return true;
    }
    

    
}
