package Objeto;


public class Cliente {

    private int idusuario;
    private String nome;
    private String email;
    private String senha;
    private String senhaconfirm;
    private int tier = 0;
    

    public int getIdusuario() {
        return idusuario;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public void setSenhaconfirm(String senhaconfirm) {
        this.senhaconfirm = senhaconfirm;
    }
    
    

    public void setIdusuario(int idusuario) {
        this.idusuario = idusuario;
    }
    
    public String getNome() {
        return nome;
    }

    public String getEmail() {
        return email;
    }

    public String getSenha() {
        return senha;
    }

    public String getSenhaconfirm() {
        return senhaconfirm;
    }

    public int getTier() {
        return tier;
    }

    public void setTier(int tier) {
        this.tier = tier;
    }


}